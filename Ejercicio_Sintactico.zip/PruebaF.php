<?php
$valorD = 8.4;
$valorE = 10;
$ValorEx = 20;

$valorD + $ValorEx;
$suma = $valorD * 2;
$suma;
16 + 8 * 21;
9 * 20 + 3;
31 +2 - 10;

$ope = 14 * ( 15 - 13 );
$ope;
$factible = $suma;

if( $valorD <= $valorE){  $a; }
else{ $a; }
if( $valorD = $valorE){  $a; }
if( $valorD != $valorE){  $a; }

for($i = 1; $i < $c; $i++) { $i; }

while($i <= $valorD){ $i++; }

$a = 0;
do{ $a; } while( $a < 0 );

?>